import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sklearn.linear_model import BayesianRidge
import lightgbm as lgb # Thêm thư viện lightgbm

# --- Tải và xử lý dữ liệu ---
@st.cache_data
def load_data(filepath):
    """
    Tải và xử lý trước dữ liệu thời tiết London.
    Sử dụng nội suy theo thời gian để điền giá trị thiếu.
    """
    df = pd.read_csv(filepath)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    df.set_index('date', inplace=True)
    df.sort_index(inplace=True)
    
    # Sử dụng nội suy theo thời gian
    df.interpolate(method='time', inplace=True)
    
    # Điền các giá trị còn lại (nếu có ở đầu file)
    if df.isnull().sum().sum() > 0:
        df.fillna(method='bfill', inplace=True)
        
    return df

# --- Hàm tiền xử lý và tạo đặc trưng cho LightGBM ---
def preprocess_for_lgbm(df):
    """
    Tạo các đặc trưng thời gian, trễ và cửa sổ trượt cho mô hình LightGBM.
    Hàm này sẽ được gọi bên trong hàm dự báo của LightGBM.
    """
    df_copy = df.copy()
    
    # 1. Đặc trưng thời gian
    df_copy['year'] = df_copy.index.year
    df_copy['month'] = df_copy.index.month
    df_copy['day'] = df_copy.index.day
    df_copy['day_of_week'] = df_copy.index.dayofweek
    df_copy['day_of_year'] = df_copy.index.dayofyear
    df_copy['week_of_year'] = df_copy.index.isocalendar().week.astype(int)

    # 2. Đặc trưng trễ (Lag Features)
    target_col = 'mean_temp'
    lags = [1, 2, 3, 7, 14, 30]
    for lag in lags:
        df_copy[f'{target_col}_lag_{lag}'] = df_copy[target_col].shift(lag)

    # 3. Đặc trưng cửa sổ trượt (Rolling Window Features)
    window_sizes = [7, 14, 30]
    for window in window_sizes:
        rolling_window = df_copy[target_col].shift(1).rolling(window=window)
        df_copy[f'{target_col}_rolling_mean_{window}'] = rolling_window.mean()
        df_copy[f'{target_col}_rolling_std_{window}'] = rolling_window.std()
        df_copy[f'{target_col}_rolling_min_{window}'] = rolling_window.min()
        df_copy[f'{target_col}_rolling_max_{window}'] = rolling_window.max()

    # Loại bỏ các dòng có giá trị NaN sau khi tạo đặc trưng
    df_copy.dropna(inplace=True)
    
    return df_copy

# --- CÁC MÔ HÌNH DỰ BÁO ---

def forecast_lightgbm(df, year):
    """
    Huấn luyện và dự báo bằng LightGBM sau khi đã tạo đặc trưng.
    """
    # 1. Tiền xử lý và tạo đặc trưng
    df_featured = preprocess_for_lgbm(df)

    # 2. Định nghĩa features và target
    target = 'mean_temp'
    # Bỏ các cột không cần thiết cho việc huấn luyện
    features_to_drop = [target, 'max_temp', 'min_temp']
    features = [col for col in df_featured.columns if col not in features_to_drop]

    # 3. Phân chia dữ liệu
    train_df = df_featured[df_featured.index.year < year]
    forecast_data_df = df_featured[df_featured.index.year == year]

    if train_df.empty:
        st.error(f"Không có đủ dữ liệu lịch sử để huấn luyện cho năm {year}.")
        return pd.DataFrame()
    if forecast_data_df.empty:
        st.error(f"Không có dữ liệu cho năm {year} để dự báo.")
        return pd.DataFrame()

    X_train = train_df[features]
    y_train = train_df[target]
    X_forecast = forecast_data_df[features]

    # 4. Huấn luyện mô hình
    lgbm = lgb.LGBMRegressor(
        objective='mae',
        metric='mae',
        n_estimators=1000,
        learning_rate=0.05,
        num_leaves=31,
        n_jobs=-1,
        seed=42,
        verbose=-1 # Tắt bớt log khi chạy trên Streamlit
    )

    # Sử dụng Early Stopping để tối ưu
    # Lấy 10% cuối của tập train làm validation set
    train_val_split_index = int(len(X_train) * 0.9)
    X_train_part = X_train[:train_val_split_index]
    y_train_part = y_train[:train_val_split_index]
    X_val_part = X_train[train_val_split_index:]
    y_val_part = y_train[train_val_split_index:]
    
    lgbm.fit(
        X_train_part, y_train_part,
        eval_set=[(X_val_part, y_val_part)],
        eval_metric='mae',
        callbacks=[lgb.early_stopping(100, verbose=False)] # verbose=False để gọn gàng hơn
    )

    # 5. Dự báo
    predictions = lgbm.predict(X_forecast)
    
    forecast_df = pd.DataFrame({'forecast': predictions}, index=X_forecast.index)
    
    return forecast_df

def forecast_bayesian_ridge(df, year):
    """
    Huấn luyện và dự báo bằng Bayesian Ridge (đơn giản hơn).
    """
    df_processed = df.copy()
    # Với mô hình đơn giản, ta điền NaN bằng mean
    for col in df_processed.columns:
        if df_processed[col].isnull().any():
            mean_value = df_processed[col].mean()
            df_processed[col] = df_processed[col].fillna(mean_value)

    features = ['cloud_cover', 'sunshine', 'global_radiation', 'max_temp', 'min_temp', 'precipitation', 'pressure', 'snow_depth']
    target = 'mean_temp'
    train_df = df_processed[df_processed.index.year < year]
    forecast_data_df = df_processed[df_processed.index.year == year]
    
    X_train = train_df[features]
    y_train = train_df[target]
    X_forecast = forecast_data_df[features]

    model = BayesianRidge()
    model.fit(X_train, y_train)
    predictions = model.predict(X_forecast)

    forecast_df = pd.DataFrame({'forecast': predictions}, index=X_forecast.index)
    return forecast_df

# --- GIAO DIỆN ỨNG DỤNG STREAMLIT ---

st.title("🌡️ Giao diện dự báo nhiệt độ London")
st.markdown("Chọn năm và mô hình bạn muốn sử dụng để xem kết quả dự báo.")

try:
    # Bước 1: Tải dữ liệu thô
    raw_df = load_data('london_weather.csv')
    
    st.sidebar.header("Tùy chọn dự báo")

    available_years = raw_df.index.year.unique().tolist()
    # Bắt đầu dự báo từ năm 1980 vì LightGBM cần dữ liệu trễ 30 ngày
    forecastable_years = [y for y in available_years if y >= 1980]
    
    year_to_forecast = st.sidebar.selectbox(
        "1. Chọn năm để dự báo:",
        options=sorted(forecastable_years, reverse=True)
    )

    models = {
        "LightGBM (Kỹ thuật Đặc trưng)": forecast_lightgbm,
        "Bayesian Ridge Regressor (Đơn giản)": forecast_bayesian_ridge,
    }
    model_name = st.sidebar.selectbox(
        "2. Chọn mô hình:",
        options=list(models.keys())
    )

    if st.sidebar.button("Dự báo", type="primary"):
        with st.spinner(f"Đang chạy dự báo cho năm {year_to_forecast} bằng mô hình '{model_name}'..."):
            
            model_function = models[model_name]
            # Truyền dữ liệu thô vào hàm, mỗi hàm sẽ tự xử lý
            forecast_df = model_function(raw_df, year_to_forecast)

            if not forecast_df.empty:
                # Dữ liệu thực tế để so sánh
                actual_df = raw_df[raw_df.index.year == year_to_forecast]

                st.subheader(f"Kết quả dự báo nhiệt độ trung bình năm {year_to_forecast}")
                
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=actual_df.index,
                    y=actual_df['mean_temp'],
                    mode='lines', name='Thực tế',
                    line=dict(color='royalblue', width=2)
                ))
                fig.add_trace(go.Scatter(
                    x=forecast_df.index,
                    y=forecast_df['forecast'],
                    mode='lines', name='Dự báo',
                    line=dict(color='orangered', width=2, dash='dash')
                ))
                fig.update_layout(
                    title=f"So sánh nhiệt độ Thực tế và Dự báo cho năm {year_to_forecast}",
                    xaxis_title="Ngày", yaxis_title="Nhiệt độ trung bình (°C)",
                    legend_title="Chú thích", hovermode="x unified"
                )
                st.plotly_chart(fig, use_container_width=True)
                
            else:
                st.warning("Không thể tạo dự báo với lựa chọn hiện tại.")
    else:
        st.info("Hãy chọn năm, mô hình và nhấn nút 'Dự báo' để xem kết quả.")

except FileNotFoundError:
    st.error("Lỗi: Không tìm thấy file `london_weather.csv`. Vui lòng đảm bảo file này nằm cùng thư mục với file `app.py`.")
except Exception as e:
    st.error(f"Đã xảy ra lỗi: {e}")